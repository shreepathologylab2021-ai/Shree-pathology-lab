Shree Pathology Lab V7 — Web HTML

Open index.html in Chrome / Edge.

Login: admin / admin123
