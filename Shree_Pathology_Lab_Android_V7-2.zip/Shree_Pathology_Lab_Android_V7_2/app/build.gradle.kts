plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android { namespace = "com.shreepathology.lab"; compileSdk = 35
    defaultConfig { applicationId = "com.shreepathology.lab"; minSdk = 24; targetSdk = 35; versionCode = 7; versionName = "7.0" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
