package com.shreepathology.lab

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val tests = arrayOf("CBC","LFT","KFT","Lipid Profile","Thyroid Profile","Urine Routine","HbA1c")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }
    private fun showLogin() {
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(40,60,40,40) }
        val title=TextView(this).apply { text="Shree Pathology Lab"; textSize=28f; setPadding(0,0,0,30) }
        val u=EditText(this).apply { hint="Username" }
        val p=EditText(this).apply { hint="Password"; inputType=129 }
        val b=Button(this).apply { text="Login" }
        box.addView(title); box.addView(u); box.addView(p); box.addView(b)
        setContentView(box)
        b.setOnClickListener { if(u.text.toString()=="admin" && p.text.toString()=="admin123") showDashboard() else Toast.makeText(this,"Invalid login",Toast.LENGTH_SHORT).show() }
    }
    private fun showDashboard() {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(25,35,25,25) }
        box.addView(TextView(this).apply { text="Dashboard"; textSize=26f })
        val items=arrayOf("Patient Registration","New Billing","Sample / Barcode","Result Entry","Reports","Patient History","Doctors","Test Master","Users & Branches","Backup")
        items.forEach { label ->
            val b=Button(this).apply { text=label }
            box.addView(b)
            b.setOnClickListener { openSection(label) }
        }
        setContentView(ScrollView(this).apply { addView(box) })
    }
    private fun openSection(name:String) {
        if(name=="Result Entry") {
            val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(25,30,25,25) }
            box.addView(TextView(this).apply { text="Result Entry"; textSize=25f })
            val patient=EditText(this).apply { hint="Patient / Bill No." }
            box.addView(patient)
            tests.forEach { t ->
                val e=EditText(this).apply { hint="$t result"; setSingleLine(true) }
                box.addView(e)
            }
            box.addView(Button(this).apply { text="Save & Verify"; setOnClickListener { Toast.makeText(this@MainActivity,"Results saved and sent for verification",Toast.LENGTH_SHORT).show() }})
            setContentView(ScrollView(this).apply { addView(box) })
        } else {
            Toast.makeText(this,"$name module ready in V7 starter",Toast.LENGTH_SHORT).show()
        }
    }
}
