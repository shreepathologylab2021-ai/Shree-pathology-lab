Shree Pathology Lab Android V7-2

This is a corrected Android project based on V7-1.
The missing Gradle wrapper launcher files have been added.

Project:
- Android Gradle Plugin 8.5.2
- Kotlin 2.0.21
- compileSdk 35
- minSdk 24

Login demo:
Username: admin
Password: admin123

Build:
1. Open the ROOT folder (the folder containing settings.gradle.kts), not the app folder.
2. Allow Gradle sync/download to finish.
3. Run the app.

Important: The gradlew launcher uses the Gradle executable available in the Android development environment. If your mobile IDE does not provide a Gradle executable, use its built-in Gradle sync/build feature or Android Studio on a computer.
