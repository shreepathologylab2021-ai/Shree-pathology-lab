@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Gradle executable not found. Open this project in Android Studio/AndroidIDE and sync Gradle.
exit /b 1
